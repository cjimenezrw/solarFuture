<?php

/**
 * Modelo de modulo de empresas
 *
 * Este es el modelo de modulo emp, osea empresas
 *
 * @author Luis Alverto Valdez Alvarez <lvaldez@woodward.com.mx>
 */
Class Empr_Model Extends DLOREAN_Model {

    // PUBLIC VARIABLES //
    /** @var array Contiene array de datos */
    public $empr = array();
    // PROTECTED VARIABLES //
    protected $solEm = array();
    protected $servem = array();
    // PRIVATE VARIABLES //
    private $data = array();

    /** @var array Contiene los datos que se requieran de sucursales para el CUD */
    protected $sucursal = array();

    /** @var array Contiene los datos que se requieran de grupos para el CUD */
    protected $grupo = array();

    /** @var array Contiene los datos que se requieran de los tipos de empresa para el CUD */
    protected $tiposEmpr = array();

    /** @var array Contiene los datos que se requieran de los tipos de empresa para el CUD */
    protected $correo = array();

    /** @var array Contiene los datos que se requieran de empresas socios para el CUD */
    protected $empresaSocio = array();

    public function __construct() {
        //parent::__construct();
    }

    public function __destruct() {

    }


    

    /**
     * Acciones de tipos de empresas
     *
     * Esta funcion ejecuta un procedimiento almacenado llamado <b>stpCUD_tiposEmpresas</b>
     * en el que estan definidas las acciones de Create Update Delete, hace uso de los datos
     * que posea la variable  <b>$grupo</b>
     *
     * @author Samuel Perez Saldivar <sperez@woodward.com.mx>
     * @return true | false True cuando todo ha salido correcto o false en caso de error
     */
    public function acciones_tiposEmpresas() {

        $sql = "CALL stpCUD_tiposEmpresas (
            " . escape($this->tiposEmpr['skEmpresaTipoViejo']) . ",
            " . escape($this->tiposEmpr['skEmpresaTipo']) . ",
            " . escape($this->tiposEmpr['skEstatus']) . ",
            " . escape($this->tiposEmpr['sNombre']) . ",
            '" . $_SESSION['usuario']['skUsuario'] . "',
            '" . $this->sysController . "')";

        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        return true;
    }

      
    /**
     * Consulta tipos de empresa
     *
     * Obtiene los datos de un grupo basado en su ID,  hace uso de los datos
     * que posea la variable  <b>$grupo</b>
     *
     * @author Samuel Perez Saldivar <sperez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla
     */
    public function consulta_tipoEmpr() {
        $select = "SELECT * FROM cat_empresasTipos WHERE skEmpresaTipo = '" . $this->tiposEmpr['skEmpresaTipo'] . "'";
        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        $record = Conn::fetch_assoc($result);
        Conn::free_result($result);
        return $record;
    }
  
    /**
     * Valida codigo de Tipo de empresa
     *
     * Consulta si un nuevo codigo de tipo de empresa esta disponible
     *
     * @author Luis Alverto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @param string $skSucursal Nuevo skSucursal a consultar
     * @return true | false Retorna true si el codigo esta disponible o false si algo falla o no esta disponible
     */
    public function validar_codigoTipoEmpresa($skEmpresaTipo) {
        $select = "SELECT skEmpresaTipo FROM cat_empresasTipos WHERE skEmpresaTipo = '" . $skEmpresaTipo . "'";
        $result = Conn::query($select);
        if (!$result) {
            return false;
        }
        if (count($result->fetchall()) > 0) {
            return false;
        }
        return true;
    }

    /**
     * Autocompletado de empresas
     *
     * Retorna un array con los datos de una busuqueda de empresas para usarla en
     * un autocompletado.
     *
     * @author Luis Alverto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @param string $value Nombre de la sucursal a buscar
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function aut_empresas($value) {

        $selec = "SELECT  es.skEmpresaSocio AS 'id', CONCAT(e.sNombre ,' (', ce.sNombre,')' ) AS 'nombre' FROM rel_empresasSocios es "
                . " INNER JOIN cat_empresas e ON e.skEmpresa = es.skEmpresa
               INNER JOIN cat_empresasTipos ce ON ce.skEmpresaTipo = es.skEmpresaTipo WHERE 1=1 ";

        if ($_SESSION['usuario']['tipoUsuario'] === 'U') {
            $selec .= " AND es.skEmpresaSocioPropietario = '" . $_SESSION['usuario']['skEmpresaSocioPropietario'] . "' ";
        }

        $selec .= " AND e.sNombre like '%" . $value . "%'  LIMIT 20 ";
        $query = Conn::query($selec);

        if (!$query) {

            return false;
        }

        $jsonData = array();
        while ($array = Conn::fetch_assoc($query)) {
            $jsonData[] = $array;
        }

        return $jsonData;
    }

    /**
     * Consulta estatus
     *
     * Consulta informacion de los estatus AC e IC
     *
     * @author Luis Alverto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla
     */
    public function consultar_estatus() {
        $select = "SELECT skEstatus,sNombre FROM core_estatus WHERE skEstatus IN ('AC','IN')";

        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        $record = Conn::fetch_assoc_all($result);
        return $record;
    }
  

    /**
     * validar_empresaSocio
     *
     * Obtiene la empresa socio por RFC y skEmpresaSocioPropietario.
     *
     * @author Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param string $sRFC RFC del empresaSocio a buscar
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function validar_empresaSocio($sRFC = NULL, $skEmpresaTipo = NULL,$sTelefono = NULL, $sCorreo = NULL, $skEmpresaSocio = NULL  ) {
        $sql = "SELECT e.*,es.skEmpresaSocio,es.skEmpresaSocioPropietario,es.skEmpresaTipo  
            FROM cat_empresas e
            LEFT JOIN rel_empresasSocios es ON es.skEmpresa = e.skEmpresa AND es.skEmpresaSocioPropietario = '" . $_SESSION['usuario']['skEmpresaSocioPropietario'] . "'";
        
        if (isset($skEmpresaTipo) && !empty($skEmpresaTipo)) {
            $sql .= " AND es.skEmpresaTipo = ".escape($skEmpresaTipo);
        }

        if (isset($skEmpresaSocio) && !empty($skEmpresaSocio)) {
            $sql .= " AND es.skEmpresaSocio != ".escape($skEmpresaSocio);
        }

        $sql .= " WHERE  es.skEstatus = 'AC' ";

        if(!empty($sRFC) || !empty($sTelefono) || !empty($sCorreo)) {
            $sql .= " AND ( 1 = 2 ";
        }

            if (isset($sRFC) && !empty($sRFC)) {
                $sql .= " OR e.sRFC = ".escape($sRFC);
            }

            if (isset($sTelefono) && !empty($sTelefono)) {
                $sql .= " OR e.sTelefono = ".escape($sTelefono);
            }

            if (isset($sCorreo) && !empty($sCorreo)) {
                $sql .= " OR e.sCorreo = ".escape($sCorreo);
            } 

        if(!empty($sRFC) || !empty($sTelefono) || !empty($sCorreo)) {
            $sql .= " ) ";
        }

        //exit($sql);
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc($result);
    }

    /**
     * consultar_empresaSocio
     *
     * Obtiene la empresa socio por skEmpresaSocio.
     *
     * @author Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param string $skEmpresaSocio identificador de la empresa socio.
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function consultar_empresaSocio($skEmpresaSocio) {
        $sql = "SELECT * FROM rel_empresasSocios es "
                . " INNER JOIN cat_empresas e ON e.skEmpresa = es.skEmpresa "
                . " WHERE es.skEmpresaSocio = '" . $skEmpresaSocio . "'";
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc($result);
    }

    /**
     * getEmpresasTipos
     *
     * Obtiene los tipos de empresas activos.
     *
     * @author Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function getEmpresasTipos() {
        $sql = "SELECT * FROM cat_empresasTipos WHERE skEstatus = 'AC' ORDER BY sNombre ASC";
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

  

    /**
     * stpCUD_empresaSocio
     *
     * Crea o Edita una empresa socio en base de datos.
     *
     * @author Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @return boolean Retorna un objeto de resultado mssql en caso de exito ó false en caso de error.
     */
    public function stpCUD_empresaSocio() {
        $sql = "CALL stpCUD_empresaSocio (
            /*@skEmpresaSocio             = */" . escape($this->empresaSocio['skEmpresaSocio']) . ",
            /*@skEmpresa                  = */" . escape($this->empresaSocio['skEmpresa']) . ",
            /*@skEmpresaSocioSugerido     = */ NULL,
            /*@skEmpresaSocioPropietario  = */" . escape($_SESSION['usuario']['skEmpresaSocioPropietario']) . ",
            /*@skEmpresaTipo              = */" . escape($this->empresaSocio['skEmpresaTipo']) . ",
            /*@sRFC                       = */" . escape($this->empresaSocio['sRFC']) . ",
            /*@sTelefono                  = */" . escape($this->empresaSocio['sTelefono']) . ",
            /*@sCorreo                    = */" . escape($this->empresaSocio['sCorreo']) . ",
            /*@sNombre                    = */" . escape($this->empresaSocio['sNombre']) . ",
            /*@sNombreCorto               = */" . escape($this->empresaSocio['sNombreCorto']) . ",
            /*@skEstatus                  = */" . escape($this->empresaSocio['skEstatus']) . ",
            /*@skUsuarioCreacion          = */" . escape($_SESSION['usuario']['skUsuario']) . ",
            /*@skModulo                   = */" . escape($this->sysController) . ")";
           
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc($result);
    }
 
    /**
     * stpCD_caracteristica_empesaSocio
     *
     * Guarda las características de empresa socio en base de datos.
     *
     * @author Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param bool $delete Acción para eliminar las caracteristicas anteriores.
     * @return bool Retorna true en caso de exito ó false en caso de error.
     */
    public function stpCD_caracteristica_empesaSocio($delete = FALSE) {
        $sql = "CALL stpCD_caracteristica_empresaSocio ( ";
        if ($delete) {
            $sql .= "
            /*@skEmpresaSocio                 = */" . escape($this->empresaSocio['skEmpresaSocio']) . ",
            /*@skCaracteristicaEmpresaSocio   = */ NULL,
            /*@sValor                         = */ NULL,
            /*@axn                            = */' DELETE',
            /*@skUsuarioCreacion              = */ NULL,
            /*@skModulo                       = */ NULL )";
        } else {
            $sql .= "
                /*@skEmpresaSocio                 = */ " . escape($this->empresaSocio['skEmpresaSocio']) . ",
                /*@skCaracteristicaEmpresaSocio   = */ " . escape($this->empresaSocio['skCaracteristicaEmpresaSocio']) . ",
                /*@sValor                         = */ " . escape($this->empresaSocio['sValor']) . ",
                /*@axn                            = */ NULL,
                /*@skUsuarioCreacion              = */ " . escape($_SESSION['usuario']['skUsuario']) . ",
                /*@skModulo                       = */ " . escape($this->sysController) . " ) ";
        }
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return TRUE;
    }

    /**
     * getCaracteristica_empesaTipo
     *
     * Obtiene todas las características activas disponibles según el tipo de empresa.
     *
     * @author   Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param    $skEmpresaTipo Tipo de empresa a la cual aplican las características, se pasa por referencia.
     * @return   mixed Retorna un objeto mssql de datos.
     */
    public function getCaracteristica_empesaTipo(&$skEmpresaTipo) {
        $sql = "SELECT c.* FROM rel_caracteristica_empresaTipo cet
        INNER JOIN cat_caracteristicasEmpresaSocio c ON c.skCaracteristicaEmpresaSocio = cet.skCaracteristicaEmpresaSocio
        WHERE c.skEstatus = 'AC' AND cet.skEmpresaTipo = '" . $skEmpresaTipo . "'";
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    /**
     * getCaracteristica_skEmpresaSocio
     *
     * Obtiene los valores de las características de una empresa socio.
     *
     * @author   Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param    $skEmpresaSocio Empresa socio, se pasa por referencia.
     * @return   mixed Retorna un objeto mssql de datos.
     */
    public function getCaracteristica_skEmpresaSocio(&$skEmpresaSocio) {
        $sql = "SELECT * FROM rel_caracteristica_empresaSocio WHERE skEmpresaSocio = '" . $skEmpresaSocio . "'";
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    /**
     * getCaracteristica_valoresCatalogo
     *
     * Obtiene los valores del catálogo utlizado para una característica para una empresa socio.
     *
     * @author   Christian Josue Jiménez Sánchez <cjimenez@woodward.com.mx>
     * @param    $sCatalogo Nombre del Catálogo (Tabla en base de datos)
     * @return   mixed Retorna un objeto mssql de datos.
     */
    public function getCaracteristica_valoresCatalogo(&$sCatalogo, &$sCatalogoKey, &$sCatalogoNombre) {
        $sql = "SELECT * FROM " . $sCatalogo;
        $where = " WHERE skEstatus = 'AC' ";
        if (isset($_POST['criterio'])) {
            $where .= " AND " . $sCatalogoNombre . " like " . escape('%' . $_POST['criterio'] . '%');
        }
        $sql .= $where;
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }
 
    public function stp_prospectos(){
        $sql = "CALL stp_prospectos (
            ".escape(isset($this->prospectos['skProspecto']) ? $this->prospectos['skProspecto'] : NULL).",
            ".escape(isset($this->prospectos['sNombreContacto']) ? $this->prospectos['sNombreContacto'] : NULL).",
            ".escape(isset($this->prospectos['sEmpresa']) ? $this->prospectos['sEmpresa'] : NULL).",
            ".escape(isset($this->prospectos['sCorreo']) ? $this->prospectos['sCorreo'] : NULL).",
            ".escape(isset($this->prospectos['sTelefono']) ? $this->prospectos['sTelefono'] : NULL).",
            ".escape(isset($this->prospectos['sComentarios']) ? $this->prospectos['sComentarios'] : NULL).",
            ".escape($_SESSION['usuario']['skEmpresaSocioPropietario']).",

            ".escape(isset($this->prospectos['axn']) ? $this->prospectos['axn'] : NULL).",
            ".escape($_SESSION['usuario']['skUsuario']).",
            ".escape($this->sysController)."
        )";
        
        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] == false){
            return $result;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record);
        return $record;
    }

    public function _get_prospecto($params){
        $sql = "SELECT      
             pros.skProspecto
            ,pros.skEmpresaSocioPropietario
            ,pros.skEstatus
            ,pros.iFolioProspecto
            ,pros.sNombreContacto
            ,pros.sEmpresa
            ,pros.sCorreo
            ,pros.sTelefono
            ,pros.sComentarios
            ,pros.skUsuarioCreacion
            ,pros.dFechaCreacion
            ,pros.skUsuarioModificacion
            ,pros.dFechaModificacion
            ,CONCAT(ucre.sNombre,' ',ucre.sApellidoPaterno) AS usuarioCreacion
            ,est.sNombre AS estatus
            ,est.sIcono AS estatusIcono
            ,est.sColor AS estatusColor
            FROM cat_prospectos pros
            INNER JOIN core_estatus est ON est.skEstatus = pros.skEstatus
            INNER JOIN cat_usuarios ucre ON ucre.skUsuario = pros.skUsuarioCreacion
            WHERE pros.skEmpresaSocioPropietario = ".escape($_SESSION['usuario']['skEmpresaSocioPropietario'])."
            AND pros.skProspecto = ".escape($params['skProspecto']);

        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] == false){
            return $result;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record);
        return $record;
    }

    public function _get_tiposDomicilios(){
        $sql = "SELECT 
            td.skTipoDomicilio AS id,td.sNombre AS nombre,
            td.skTipoDomicilio,td.skEstatus,td.sNombre,td.dFechaCreacion,td.skUsuarioCreacion
        FROM cat_tiposDomicilios td WHERE td.skEstatus = 'AC' ";

        if(isset($this->empr['sNombre']) && !empty(trim($this->empr['sNombre']))){
            $sql .= " AND td.sNombre LIKE '%" . trim($this->empr['sNombre']) . "%' ";
        }

        $sql .= " ORDER BY td.sNombre ASC ";
        
        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] != 1){
            return $result;
        }

        $records = Conn::fetch_assoc_all($result);
        utf8($records, FALSE);
        return $records;
    }

    public function _get_paises(){
        $sql = "SELECT 
            pa.skPais AS id,pa.sNombre AS nombre,
            pa.skPais,pa.skEstatus,pa.sClave,pa.sNombre
        FROM cat_paises pa WHERE pa.skEstatus = 'AC' ";

        if(isset($this->empr['sNombre']) && !empty(trim($this->empr['sNombre']))){
            $sql .= " AND pa.sNombre LIKE '%" . trim($this->empr['sNombre']) . "%' ";
        }

        $sql .= " ORDER BY pa.sNombre ASC ";
        
        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] != 1){
            return $result;
        }

        $records = Conn::fetch_assoc_all($result);
        utf8($records, FALSE);
        return $records;
    }

    public function _get_estados(){
        $sql = "SELECT 
            es.skEstadoMX AS id,es.sNombre AS nombre,
            es.skEstadoMX,es.skPais,es.sClave,es.sNombre,es.sAbrev,es.skEstatus
        FROM cat_estadosMX es WHERE es.skEstatus = 'AC' ";

        if(isset($this->empr['sNombre']) && !empty(trim($this->empr['sNombre']))){
            $sql .= " AND es.sNombre LIKE '%" . trim($this->empr['sNombre']) . "%' ";
        }

        $sql .= " ORDER BY es.sNombre ASC ";
        
        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] != 1){
            return $result;
        }

        $records = Conn::fetch_assoc_all($result);
        utf8($records, FALSE);
        return $records;
    }

    public function stp_empresasSocios_domicilios(){
        $sql = "CALL stp_empresasSocios_domicilios (
            ".escape(isset($this->empr['skEmpresaSocioDomicilio']) ? $this->empr['skEmpresaSocioDomicilio'] : NULL) . ",
            ".escape(isset($this->empr['skEmpresaSocio']) ? $this->empr['skEmpresaSocio'] : NULL) . ",
            ".escape(isset($this->empr['skTipoDomicilio']) ? $this->empr['skTipoDomicilio'] : NULL) . ",
            ".escape(isset($this->empr['skEstatus']) ? $this->empr['skEstatus'] : NULL) . ",
            ".escape(isset($this->empr['skPais']) ? $this->empr['skPais'] : NULL) . ",
            ".escape(isset($this->empr['skEstado']) ? $this->empr['skEstado'] : NULL) . ",
            ".escape(isset($this->empr['skMunicipio']) ? $this->empr['skMunicipio'] : NULL) . ",
            ".escape(isset($this->empr['sColonia']) ? $this->empr['sColonia'] : NULL) . ",
            ".escape(isset($this->empr['sCalle']) ? $this->empr['sCalle'] : NULL) . ",
            ".escape(isset($this->empr['sCodigoPostal']) ? $this->empr['sCodigoPostal'] : NULL) . ",
            ".escape(isset($this->empr['sNumeroExterior']) ? $this->empr['sNumeroExterior'] : NULL) . ",
            ".escape(isset($this->empr['sNumeroInterior']) ? $this->empr['sNumeroInterior'] : NULL). ",
            ".escape(isset($this->empr['sNombre']) ? $this->empr['sNombre'] : NULL) . ",

            ".escape(isset($this->empr['axn']) ? $this->empr['axn'] : NULL) . ",
            ".escape($_SESSION['usuario']['skUsuario']). ",
            ".escape($this->sysController)." )";

        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        $record = Conn::fetch_assoc($result);
        return $record;
    }

    public function _get_empresasSocios_domicilios(){
        $sql = "SELECT 
             dom.skEmpresaSocioDomicilio
            ,dom.skEmpresaSocio
            ,dom.skTipoDomicilio
            ,dom.skEstatus
            ,dom.skPais
            ,dom.skEstado
            ,dom.skMunicipio
            ,dom.sColonia
            ,dom.sCalle
            ,dom.sCodigoPostal
            ,dom.sNumeroExterior
            ,dom.sNumeroInterior
            ,dom.sNombre
            ,dom.skUsuarioCreacion
            ,dom.dFechaCreacion
            ,dom.skUsuarioModificacion
            ,dom.dFechaModificacion
            
            ,td.sNombre AS tipoDomicilio
            ,est.sNombre AS estatus
            ,pa.sNombre AS pais
            ,esta.sNombre AS estado
            
            FROM rel_empresasSocios_domicilios dom 
            INNER JOIN rel_empresasSocios es ON es.skEmpresaSocio = dom.skEmpresaSocio
            INNER JOIN cat_empresas e ON e.skEmpresa = es.skEmpresa
            INNER JOIN cat_tiposDomicilios td ON td.skTipoDomicilio = dom.skTipoDomicilio
            INNER JOIN core_estatus est ON est.skEstatus = dom.skEstatus
            INNER JOIN cat_paises pa ON pa.skPais = dom.skPais
            INNER JOIN cat_estadosMX esta ON esta.skEstadoMX = dom.skEstado
            INNER JOIN cat_usuarios uCre ON uCre.skUsuario = dom.skUsuarioCreacion
            LEFT JOIN cat_usuarios uMod ON uMod.skUsuario = dom.skUsuarioModificacion
            WHERE 1=1 ";

        if(isset($this->empr['skEmpresaSocio']) && !empty($this->empr['skEmpresaSocio'])){
            if(is_array($this->empr['skEmpresaSocio'])){
                $sql .= " AND dom.skEmpresaSocio IN (" . mssql_where_in($this->empr['skEmpresaSocio']) . ") ";
            }else{
                $sql .= " AND dom.skEmpresaSocio = " . escape($this->empr['skEmpresaSocio']);
            }
        }

        $sql .= " ORDER BY dom.dFechaCreacion DESC ";
                
        $result = Conn::query($sql);
        if(is_array($result) && isset($result['success']) && $result['success'] != 1){
            return $result;
        }

        $records = Conn::fetch_assoc_all($result);
        utf8($records, FALSE);
        return $records;

    }

}