<?php

Class Inic_clie_Controller Extends Inic_Model
{
    // PUBLIC VARIABLES //

    // PROTECTED VARIABLES //

    // PRIVATE VARIABLES //
    private $data = array();

    public function __construct()
    {

    }

    public function __destruct()
    {

    }




}
