<?php
Class Inic_testing_Controller Extends Inic_Model {
    // PUBLIC VARIABLES //

    // PROTECTED VARIABLES //

    // PRIVATE VARIABLES //
        private $data = array();

    public function __construct(){

    }

    public function __destruct(){

    }
    
    
    
}
