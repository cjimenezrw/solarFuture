<h1>VIEW PERFIL</h1>
<?php
    echo '<hr>MODULO CARGADO: inic_sesi';
    echo('<pre>'.print_r($_GET,1).'</pre><hr>');
?>