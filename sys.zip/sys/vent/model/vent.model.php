<?php

Class Vent_Model Extends DLOREAN_Model {

    // PUBLIC VARIABLES //
    // PROTECTED VARIABLES //
    protected $vent = array(); 
  
    // PRIVATE VARIABLES //
    private $data = array();

    public function __construct() {
        //parent::__construct();
    }

    public function __destruct() {

    }
   
 
     
    public function stpCUD_cotizaciones() {

        $sql = "CALL stpCUD_cotizaciones (
            " .escape(isset($this->vent['skCotizacion']) ? $this->vent['skCotizacion'] : NULL) . ",
            " .escape(isset($this->vent['skCotizacionServicio']) ? $this->vent['skCotizacionServicio'] : NULL) . ",
            " .escape(isset($this->vent['skEstatus']) ? $this->vent['skEstatus'] : NULL) . ",
            " .escape(isset($this->vent['skDivisa']) ? $this->vent['skDivisa'] : NULL) . ",
            " .escape(isset($this->vent['dFechaVigencia']) ? $this->vent['dFechaVigencia'] : NULL) . ",
            " .escape(isset($this->vent['skEmpresaSocioCliente']) ? $this->vent['skEmpresaSocioCliente'] : NULL) . ",
            " .escape(isset($this->vent['sNombreCliente']) ? $this->vent['sNombreCliente'] : NULL) . ",
            " .escape(isset($this->vent['skProspecto']) ? $this->vent['skProspecto'] : NULL) . ",
            " .escape(isset($this->vent['sObservaciones']) ? $this->vent['sObservaciones'] : NULL) . ",
            " .escape(isset($this->vent['sObservacionesCancelacion']) ? $this->vent['sObservacionesCancelacion'] : NULL) . ",
            " .escape(isset($this->vent['sCondicion']) ? $this->vent['sCondicion'] : NULL) . ",
            " .escape(isset($this->vent['fImporteSubtotal']) ? $this->vent['fImporteSubtotal'] : NULL) . ",
            " .escape(isset($this->vent['fDescuento']) ? $this->vent['fDescuento'] : NULL) . ",
            " .escape(isset($this->vent['fImpuestosTrasladados']) ? $this->vent['fImpuestosTrasladados'] : NULL) . ",
            " .escape(isset($this->vent['fImpuestosRetenidos']) ? $this->vent['fImpuestosRetenidos'] : NULL) . ",
            " .escape(isset($this->vent['fImporteTotal']) ? $this->vent['fImporteTotal'] : NULL) . ",
            " .escape(isset($this->vent['fTipoCambio']) ? $this->vent['fTipoCambio'] : NULL) . ",
            " .escape(isset($this->vent['skServicio']) ? $this->vent['skServicio'] : NULL) . ",
            " .escape(isset($this->vent['skTipoMedida']) ? $this->vent['skTipoMedida'] : NULL) . ",
            " .escape(isset($this->vent['skImpuesto']) ? $this->vent['skImpuesto'] : NULL) . ",
            " .escape(isset($this->vent['sDescripcion']) ? $this->vent['sDescripcion'] : NULL) . ",
            " .escape(isset($this->vent['fCantidad']) ? $this->vent['fCantidad'] : NULL) . ",
            " .escape(isset($this->vent['fPrecioUnitario']) ? $this->vent['fPrecioUnitario'] : NULL) . ",
            " .escape(isset($this->vent['fImporte']) ? $this->vent['fImporte'] : NULL) . ",
            " .escape(isset($this->vent['sCorreo']) ? $this->vent['sCorreo'] : NULL) . ",
            " .escape(isset($this->vent['skInformacionProductoServicio']) ? $this->vent['skInformacionProductoServicio'] : NULL) . ",
            " .escape(isset($this->vent['skCatalogoSistemaOpciones']) ? $this->vent['skCatalogoSistemaOpciones'] : NULL) . ",
            " .escape(isset($this->vent['fCostoRecibo']) ? $this->vent['fCostoRecibo'] : NULL) . ",
            " .escape(isset($this->vent['iInformacionPanel']) ? $this->vent['iInformacionPanel'] : NULL) . ",
            " .escape(isset($this->vent['fKwGastados']) ? $this->vent['fKwGastados'] : NULL) . ",
            " .escape(isset($this->vent['skCategoriaPrecio']) ? $this->vent['skCategoriaPrecio'] : NULL) . ",
            " .escape(isset($this->vent['sDireccion']) ? $this->vent['sDireccion'] : NULL) . ",
            " .escape(isset($this->vent['sRPU']) ? $this->vent['sRPU'] : NULL) . ",
            " .escape(isset($this->vent['sTelefono']) ? $this->vent['sTelefono'] : NULL) . ",
            " .escape(isset($this->vent['TARIFA']) ? $this->vent['TARIFA'] : NULL) . ",

            " .escape(isset($this->vent['axn']) ? $this->vent['axn'] : NULL) . ",
            '" . $_SESSION['usuario']['skUsuario'] . "',
            '" . $this->sysController . "' )";
         
        if($this->vent['axn'] == 'guardar_cotizacion_servicios'){
            //exit('<pre>'.print_r($sql,1).'</pre>');
        }
        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record);
        return $record; 
    }


    /**
     * _getCotizacion
     *
     * Obtener Datos de Cotizacion guardada
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return Array Datos | False
     */
    public function _getCotizacion() {

        $sql = "SELECT 
        oc.skCotizacion,
        oc.skEstatus,
        CONCAT('SFM',RIGHT(CONCAT('0000',CAST(oc.iFolio AS VARCHAR(4))),4)) AS iFolio,
        oc.dFechaVigencia,
        oc.skDivisa,
        oc.skEmpresaSocioCliente,
        oc.skProspecto,
        oc.sObservaciones,
        oc.sCondicion,
        oc.fImporteSubtotal,
        oc.fDescuento,
        oc.fImpuestosTrasladados,
        oc.fImpuestosRetenidos,
        oc.fImporteTotal,
        oc.fTipoCambio,
        oc.fCostoRecibo,
        oc.iInformacionPanel,
        oc.fKwGastados,
        oc.skCategoriaPrecio,
        oc.sDireccion,
        oc.sRPU,
        oc.sTelefono,
        oc.TARIFA,
        oc.dFechaCreacion,
        oc.skEstatusActaEntrega,
        oc.sRecibeEntrega,
        oc.sTelefonoRecepcionEntrega,
        oc.dFechaEntregaInstalacion,
        oc.sObservacionesInstalacion,
        IF(oc.sNombreCliente IS NOT NULL, oc.sNombreCliente, IF(cep.sNombreCorto IS NOT NULL, cep.sNombreCorto, cep.sNombre)) AS sNombreCliente,
        IF(cep.sNombreCorto IS NOT NULL, cep.sNombreCorto, cep.sNombre) AS cliente,
        cep.sRFC AS clienteRFC,
        cp.sNombreContacto AS prospecto,
        rca.sNombre AS categoria,
        cu.sNombre AS usuarioCreacion,
        (SELECT SUM(cc2.fMetros2*rcc.fCantidad) FROM rel_cotizaciones_servicios rcc  
        INNER JOIN cat_servicios cc2 ON cc2.skServicio = rcc.skServicio AND cc2.skCategoriaProducto = 'PANSOL' 
        WHERE rcc.skCotizacion = oc.skCotizacion ) AS metros2,
        (SELECT SUM(rcc.fCantidad) FROM rel_cotizaciones_servicios rcc  
        INNER JOIN cat_servicios cc2 ON cc2.skServicio = rcc.skServicio AND cc2.skCategoriaProducto = 'PANSOL' 
        WHERE rcc.skCotizacion = oc.skCotizacion ) AS cantidadPanel,
        (SELECT  (SUM(fKwServicio)/1000) FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS capacidad,
        (SELECT  ((SUM(fKwServicio)*4.5)/1000) FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS produccionDiaria,
        (SELECT  ((SUM(fKwServicio)*4.5)/1000)*30 FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS produccionMensual,
        (SELECT  ((SUM(fKwServicio)*4.5)/1000)*60 FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS produccionBimestral,
        (SELECT  ((SUM(fKwServicio)*4.5)/1000)*365 FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS produccionAnual,
        (SELECT  ((((SUM(fKwServicio)*4.5)/1000)*365) /(oc.fKwGastados*(IF(TARIFA = 'INDUSTRIAL',12,6)))*100) FROM rel_cotizaciones_servicios WHERE skCotizacion = oc.skCotizacion  ) AS porcentajeAnualCubierto,

        ROUND(ROUND(oc.fImporteTotal/oc.fCostoRecibo,1)/(IF(TARIFA = 'INDUSTRIAL',12,6)),1) AS recuperacionInversion,
        (oc.fCostoRecibo * (IF(TARIFA = 'INDUSTRIAL',12,6))) AS gastoAnual,
        (oc.fKwGastados * (IF(TARIFA = 'INDUSTRIAL',12,6))) AS consumoAnual,
        (oc.fImporteTotal /(oc.fKwGastados * (IF(TARIFA = 'INDUSTRIAL',12,6)))) AS precioPromedio
        
        FROM ope_cotizaciones oc 

        LEFT JOIN rel_empresasSocios resc ON resc.skEmpresaSocio = oc.skEmpresaSocioCliente
        LEFT JOIN cat_empresas cep ON cep.skEmpresa = resc.skEmpresa
        LEFT JOIN cat_prospectos cp ON cp.skProspecto = oc.skEmpresaSocioCliente
        LEFT JOIN cat_usuarios cu ON cu.skUsuario = oc.skUsuarioCreacion 
        LEFT JOIN rel_catalogosSistemasOpciones rca ON rca.skCatalogoSistemaOpciones = oc.skCategoriaPrecio
 
        WHERE  oc.skCotizacion =  " . escape($this->vent['skCotizacion']);

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc($result);
    }

    public function _getCotizacionservicios_inventario(){
        $sql = "SELECT 
        cc.sCodigo,
        cc.sNombre AS servicio,
        rcc.sDescripcion,
        rci.sNumeroSerie
        FROM rel_cotizaciones_servicios rcc
        INNER JOIN cat_servicios cc ON cc.skServicio = rcc.skServicio
        INNER JOIN rel_servicios_inventarios rci ON rci.skCotizacionServicio = rcc.skCotizacionServicio
        WHERE rcc.skCotizacion = ".escape($this->vent['skCotizacion'])." AND cc.iDetalle = 1
        ORDER BY cc.sNombre ASC";
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

     /**
     * _getCotizacionservicios
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getCotizacionservicios() {

        $sql = "SELECT DISTINCT
		                cse.skCotizacionServicio,
		                cse.skCotizacion,
		                cse.skServicio,
                        cse.skTipoMedida,
                        cse.fCantidad,
                        cse.fPrecioUnitario,
                        cse.fImporte,
                        cse.sDescripcion,
                        cc.sNombre AS servicio,
                        cc.sCodigo AS sCodigo,
                        cc.iDetalle,
                        cum.sNombre as tipoMedida
		                FROM rel_cotizaciones_servicios cse 
                        INNER JOIN cat_servicios cc ON cc.skServicio = cse.skServicio
                        LEFT JOIN cat_unidadesMedidaSAT cum ON cum.skUnidadMedida = cse.skTipoMedida
		                WHERE cse.skCotizacion = " . escape($this->vent['skCotizacion']);

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        $i = 0;
        foreach ($records as $value) {

            $this->vent['skCotizacionServicio'] = $value['skCotizacionServicio'];

            $this->vent['skServicio'] = $value['skServicio'];
            $records[$i]['impuestos'] = $this->_getCotizacionservicios_impuestos();
            $records[$i]['venta'] = $this->_getCotizacionservicios_ventas();
            $i++;
        }
       
        return $records;
    }
     /**
     * _getCotizacionservicios_impuestos
     *
     * Función Para obtener los datos de los almacenes
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getCotizacionservicios_impuestos() {

        $sql = "SELECT	
            ras.skTipoImpuesto  AS tipoImpuesto,
            ci.sNombre AS impuesto
            FROM rel_cotizaciones_serviciosImpuestos ras
            INNER JOIN cat_impuestos ci ON ci.skImpuesto = ras.skImpuesto
            WHERE ras.skCotizacion = " . escape($this->vent['skCotizacion']) . " AND ras.skCotizacionServicio = " . escape($this->vent['skCotizacionServicio']) . "  AND ras.skServicio = " . escape($this->vent['skServicio']);

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        return $records;
    }
    /**
     * _getCotizacionservicios_ventas
     *
     * Función Para obtener los datos de los almacenes
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getCotizacionservicios_ventas() {

        $sql = "SELECT	  
        rci.sNumeroSerie,
        rci.skServicioInventario
        FROM rel_cotizaciones_servicios  ras
        INNER JOIN rel_servicios_inventarios rci ON rci.skCotizacionServicio = ras.skCotizacionServicio
        WHERE ras.skCotizacion = " . escape($this->vent['skCotizacion']) . " AND ras.skCotizacionServicio = " . escape($this->vent['skCotizacionServicio']) . "  AND ras.skServicio = " . escape($this->vent['skServicio']);

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        return $records;
    }
     /**
     * _getCotizacionCorreos
     *
     * Función Para obtener los correos de las cotizaciones
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getCotizacionCorreos() {

        $sql = "SELECT rcc.sCorreo FROM rel_cotizaciones_correos rcc WHERE  rcc.skCotizacion= " . escape($this->vent['skCotizacion']);
   
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        return $records;
    }


    /**
       * consultar_unidadesMedida
       *
       * Obtiene los tipos de procesos activos para servicios
       *
       * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
       * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
       */
      public function consultar_unidadesMedida() {
        $sql = "SELECT skUnidadMedida, CONCAT('(',sClaveSAT,') ', sNombre)  AS sNombre FROM cat_unidadesMedidaSAT
        WHERE skEstatus = 'AC' ";


        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    /**
     * getImpuestos
     *
     * Obtiene los impuestos que pueden aplicar al Servicio
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function getImpuestos() {
        $sql = "SELECT cim.skImpuesto AS id,CONCAT( cim.skTipoImpuesto,'-',cim.sNombre,'(', cim.svalor,'%)') AS nombre
                FROM cat_impuestos cim
                WHERE cim.skEstatus = 'AC' ";


        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    public function _getServicioImpuestos() {
        $select = "SELECT cim.skImpuesto,CONCAT( cim.skTipoImpuesto,'-',cim.sNombre,'(', cim.svalor,'%)')  AS nombre 
                    FROM rel_servicios_impuestos  rci
                    INNER JOIN cat_impuestos cim ON cim.skImpuesto = rci.skImpuesto
                    where rci.skServicio = '".$this->vent['skServicio']."' ";
       
        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    /**
     * get_empresas
     *
     * Consulta Empresas Socios
     *
     * @author Luis Valdez <lvaldez@softlab.com.mx>
     * @return Array Datos | False
     */
    public function get_empresas() {
        $sql = "SELECT N1.* FROM (
            SELECT
            es.skEmpresaSocio AS id, CONCAT(e.sNombre,' (',e.sRFC,') - ',et.sNombre) AS nombre, es.skEmpresaTipo
            ,e.sNombre AS sNombreEmpresa,e.sCorreo,e.sTelefono
            ,CONCAT(dom.sColonia,', ',dom.sCalle,' #',dom.sNumeroExterior,', ',dom.skMunicipio) AS domicilio
            FROM rel_empresasSocios es
            INNER JOIN cat_empresas e ON e.skEmpresa = es.skEmpresa
            INNER JOIN cat_empresasTipos et ON et.skEmpresaTipo = es.skEmpresaTipo
            LEFT JOIN rel_empresasSocios_domicilios dom ON dom.skEmpresaSocio = es.skEmpresaSocio
            WHERE es.skEstatus = 'AC' AND e.skEstatus = 'AC' AND es.skEmpresaSocioPropietario = " . escape($_SESSION['usuario']['skEmpresaSocioPropietario']);

        if (isset($this->vent['skEmpresaTipo']) && !empty($this->vent['skEmpresaTipo'])) {
            if (is_array($this->vent['skEmpresaTipo'])) {
                $sql .= " AND es.skEmpresaTipo IN (" . mssql_where_in($this->vent['skEmpresaTipo']) . ") ";
            } else {
                $sql .= " AND es.skEmpresaTipo = " . escape($this->vent['skEmpresaTipo']);
            }
        }

        $sql .= " ) AS N1 WHERE 1=1 ";

        if (isset($this->vent['sNombre']) && !empty(trim($this->vent['sNombre']))) {
            $sql .= " AND N1.nombre LIKE '%" . trim($this->vent['sNombre']) . "%' ";
        }

        if (isset($this->vent['skEmpresaSocio']) && !empty($this->vent['skEmpresaSocio'])) {
            $sql .= " AND N1.id = " . escape($this->vent['skEmpresaSocio']);
        }

        $sql .= " ORDER BY N1.nombre ASC ";
       
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

    public function get_empresasProspectos() {

        $sql = "SELECT N1.* FROM (
            SELECT
            cp.skProspecto AS id, CONCAT(cp.sNombreContacto,' - Prospecto') AS nombre
            FROM cat_prospectos cp
            WHERE cp.skEstatus = 'NU'
            UNION 
            SELECT
            es.skEmpresaSocio AS id, CONCAT(e.sNombre,' (',e.sRFC,') - Cliente') AS nombre
            FROM rel_empresasSocios es
            INNER JOIN cat_empresas e ON e.skEmpresa = es.skEmpresa
            WHERE es.skEstatus = 'AC' AND e.skEstatus = 'AC' AND es.skEmpresaTipo IN ('CLIE') "; 

      
        $sql .= " ) AS N1 ";
        

        if (isset($this->vent['sNombre']) && !empty(trim($this->vent['sNombre']))) {
            $sql .= " WHERE N1.nombre LIKE '%" . trim($this->vent['sNombre']) . "%' ";
        }

        $sql .= " ORDER BY N1.nombre ASC ";
    
       
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

    public function get_prospectos() {

        $sql = "SELECT N1.* FROM (
            SELECT
            cp.skProspecto AS id, cp.sNombreContacto AS nombre
            FROM cat_prospectos cp
            WHERE cp.skEstatus = 'NU' "; 

      
        $sql .= " ) AS N1 ";

        if (isset($this->vent['sNombre']) && !empty(trim($this->vent['sNombre']))) {
            $sql .= " WHERE N1.nombre LIKE '%" . trim($this->vent['sNombre']) . "%' ";
        }

        $sql .= " ORDER BY N1.nombre ASC ";
       
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

    /**
     * consultar_tiposMedidas
     *
     * Obtiene los tipos de medidas activas
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function consultar_tiposMedidas() {
        $sql = "SELECT skUnidadMedida AS id,sNombre AS nombre  FROM cat_unidadesMedidaSAT
        WHERE skEstatus = 'AC' ";
        if (!empty(trim($_POST['val']))) {
            $sql .= " AND sNombre   LIKE '%" . escape($_POST['val'], false) . "%' ";
        }

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

     /**
     * consultar_servicios
     *
     * Obtiene los servicios disponibles
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function consultar_servicios() {
        $sql = "SELECT skServicio AS id,sNombre AS nombre  FROM cat_servicios
				WHERE skEstatus = 'AC' ";
        if (!empty(trim($_POST['val']))) {
            if(isset($_POST['filter']) && $_POST['filter'] == 'like'){
                $arr_str = explode(' ',trim($_POST['val']));
                foreach($arr_str AS $str){
                    if(!empty(trim($str))){
                        $sql .= " AND sNombre LIKE '%".escape($str,false)."%' ";
                    }
                }
            }else{
                $sql .= " AND sNombre LIKE '%".escape($_POST['val'],false)."%' ";
            }
        }

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records,FALSE);
        return $records;
    }
    /**
     * consultar_servicios_datos
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function consultar_servicios_datos() {

        $sql = "SELECT   rcp.fPrecioVenta 
        FROM cat_servicios cse 
        LEFT JOIN rel_servicios_precios rcp ON rcp.skServicio = cse.skServicio 
        WHERE cse.skServicio = " . escape($this->vent['skServicio']);

        if (isset($this->vent['skCategoriaPrecio']) && !empty($this->vent['skCategoriaPrecio'])) {
            $sql .= " AND rcp.skCategoriaPrecio = ".escape($this->vent['skCategoriaPrecio'])." LIMIT 1 ";
        }else{
            $sql .= " ORDER BY rcp.fPrecioVenta DESC LIMIT 1 ";
        } 


        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc($result);
    }
    /**
     * consultar_servicios_impuestos
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function consultar_servicios_impuestos() {

        $sql = "SELECT DISTINCT
		                cse.skServicio,
                        resi.skImpuesto,
                        resi.skTipoImpuesto,
                        resi.sValor,
                        cse.fPrecioVenta
		                FROM cat_servicios cse
		                INNER JOIN rel_servicios_impuestos resi ON resi.skServicio = cse.skServicio

		                WHERE cse.skServicio = " . escape($this->vent['skServicio']);

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    /**
     * _getDivisas
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getDivisas() {

        $sql = "SELECT DISTINCT
		                cd.skDivisa,
                        cd.sNombre 
		                FROM cat_divisas cd WHERE skEstatus='AC'";

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }
    /**
     * _getCategorias
     *
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return array | false Retorna array de datos o false en caso de error
     */
    public function _getCategorias() {

        $sql = "SELECT cso.sNombre,cso.skCatalogoSistemaOpciones AS skCategoriaPrecio  FROM cat_catalogosSistemas cs
        INNER JOIN rel_catalogosSistemasOpciones cso ON cso.skCatalogoSistema = cs.skCatalogoSistema 
        WHERE cs.skCatalogoSistema = 'CATPRE' AND cso.skEstatus = 'AC'";

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }


    /**
     * _getInformacionProducto
     *
     * Obtiene los tipos de procesos activos para servicios
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function _getInformacionProducto() {
        $sql = "SELECT skInformacionProductoServicio,sNombre AS informacionProducto FROM cat_informacionProductoServicio
        WHERE skEstatus = 'AC' ";


        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    public function _getCotizacionInformacionProducto() {

        // SE COMENTÓ PARA REALIZARSE UNA FUNCIÓN POR SEPARADO

        /*if(in_array($this->sysController,['coti-deta','coti-form'])){
            $select = "SELECT cip.skInformacionProductoServicio,cip.sNombre,cip.sDescripcionHoja1,cip.sDescripcionHoja2,cip.sDescripcionGarantia,cip.sImagen
            FROM rel_cotizacion_informacionProducto rci
            LEFT JOIN cat_informacionProductoServicio cip ON cip.skInformacionProductoServicio = rci.skInformacionProductoServicio
            WHERE rci.skCotizacion = ".escape($this->vent['skCotizacion']);
        }else{
            $select = "SELECT cip.skInformacionProductoServicio,cip.sNombre,cip.sDescripcionHoja1,cip.sDescripcionHoja2,cip.sDescripcionGarantia,cip.sImagen,c.fKwh,cc.fCantidad
            FROM rel_cotizacion_informacionProducto rci
            LEFT JOIN cat_informacionProductoServicio cip ON cip.skInformacionProductoServicio = rci.skInformacionProductoServicio
            LEFT JOIN cat_servicios c ON c.skInformacionProductoServicio = cip.skInformacionProductoServicio
            LEFT JOIN rel_cotizaciones_servicios cc ON cc.skServicio = c.skServicio AND cc.skCotizacion = rci.skCotizacion
            WHERE rci.skCotizacion = ".escape($this->vent['skCotizacion'])." AND cc.skServicio IS NOT NULL ";    
        }*/

        $select = "SELECT cip.skInformacionProductoServicio,cip.sNombre,cip.sDescripcionHoja1,cip.sDescripcionHoja2,cip.sDescripcionGarantia,cip.sImagen
            FROM rel_cotizacion_informacionProducto rci
            LEFT JOIN cat_informacionProductoServicio cip ON cip.skInformacionProductoServicio = rci.skInformacionProductoServicio
            WHERE rci.skCotizacion = ".escape($this->vent['skCotizacion']);

        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }

    public function _getCotizacionInformacionProductoPDF() {

        /*$select = "SELECT cip.skInformacionProductoServicio,cip.sNombre,cip.sDescripcionHoja1,cip.sDescripcionHoja2,cip.sDescripcionGarantia,cip.sImagen,c.fKwh,cc.fCantidad
            FROM rel_cotizacion_informacionProducto rci
            LEFT JOIN cat_informacionProductoServicio cip ON cip.skInformacionProductoServicio = rci.skInformacionProductoServicio
            LEFT JOIN cat_servicios c ON c.skInformacionProductoServicio = cip.skInformacionProductoServicio
            LEFT JOIN rel_cotizaciones_servicios cc ON cc.skServicio = c.skServicio AND cc.skCotizacion = rci.skCotizacion
            WHERE rci.skCotizacion = ".escape($this->vent['skCotizacion'])." AND cc.skServicio IS NOT NULL ";*/    

        $select = "SELECT DISTINCT
            cip.skInformacionProductoServicio,cip.sNombre,cip.sDescripcionHoja1,cip.sDescripcionHoja2,cip.sDescripcionGarantia,cip.sImagen,c.fKwh,cc.fCantidad
            FROM ope_cotizaciones coti 
            LEFT JOIN rel_cotizaciones_servicios cc ON cc.skCotizacion = coti.skCotizacion
            LEFT JOIN cat_servicios c ON c.skServicio = cc.skServicio
            LEFT JOIN cat_informacionProductoServicio cip ON cip.skInformacionProductoServicio = c.skInformacionProductoServicio
            WHERE coti.skCotizacion = ".escape($this->vent['skCotizacion'])." AND cip.skInformacionProductoServicio IS NOT NULL;";

        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }
    

    /**
     * _getTerminosCondiciones
     *
     * Obtiene los tipos de procesos activos para servicios
     *
     * @author Luis Alberto Valdez Alvarez <lvaldez@woodward.com.mx>
     * @return object | false Retorna el objeto de resultados de la consulta o false si algo falla.
     */
    public function _getTerminosCondiciones() {
        $sql = "SELECT skCatalogoSistemaOpciones,sNombre AS terminoCondicion 
        FROM rel_catalogosSistemasOpciones
        WHERE skEstatus = 'AC' AND skCatalogoSistema = 'TERCOT' ORDER BY sNombre ASC ";


        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    public function _getCotizacionTerminosCondiciones() {
        $select = "SELECT rci.skCatalogoSistemaOpciones,rcs.sNombre AS  terminoCondicion
        FROM rel_cotizaciones_terminosCondiciones rci
        LEFT JOIN rel_catalogosSistemasOpciones rcs ON rcs.skCatalogoSistemaOpciones = rci.skCatalogoSistemaOpciones AND rcs.skCatalogoSistema = 'TERCOT'
         where rci.skCotizacion = " . escape($this->vent['skCotizacion'])." ORDER BY rcs.sNombre ASC ";
          
        $result = Conn::query($select);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

     /**
     * get_serviciosInventario
     *
     * Consulta 
     *
     * @author Luis Valdez <lvaldez@softlab.com.mx>
     * @return Array Datos | False
     */
    public function get_serviciosInventario() {
        $sql = "SELECT N1.* FROM (
            SELECT
            rci.skServicioInventario AS id, rci.sNumeroSerie AS nombre 
            FROM rel_servicios_inventarios rci 
            WHERE rci.skEstatus = 'NU' AND rci.skServicio = " . escape($this->vent['skServicio']);

  

        $sql .= " ) AS N1 ";

        if (isset($this->vent['sNombre']) && !empty(trim($this->vent['sNombre']))) {
            $sql .= " WHERE N1.nombre LIKE '%" . trim($this->vent['sNombre']) . "%' ";
        }
 

        $sql .= " ORDER BY N1.nombre ASC ";
  
       
        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        $records = Conn::fetch_assoc_all($result);
        utf8($records);
        return $records;
    }
    public function stpCUD_serviciosInventario() {

        $sql = "CALL stpCUD_serviciosInventario (
            " .escape(isset($this->vent['skServicio']) ? $this->vent['skServicio'] : NULL) . ",
            " .escape(isset($this->vent['skCotizacion']) ? $this->vent['skCotizacion'] : NULL) . ",
            " .escape(isset($this->vent['skCotizacionServicio']) ? $this->vent['skCotizacionServicio'] : NULL) . ",
            " .escape(isset($this->vent['skServicioInventario']) ? $this->vent['skServicioInventario'] : NULL) . ",
            " .escape(isset($this->vent['skEstatus']) ? $this->vent['skEstatus'] : NULL) . ",
            " .escape(isset($this->vent['fCantidad']) ? $this->vent['fCantidad'] : NULL) . ",
            " .escape(isset($this->vent['sNumeroSerie']) ? $this->vent['sNumeroSerie'] : NULL) . ",
            " .escape(isset($this->conc['skUsuarioBaja']) ? $this->conc['skUsuarioBaja'] : NULL) . ",
            " .escape(isset($this->conc['sDescripcionBaja']) ? $this->conc['sDescripcionBaja'] : NULL) . ",
            " .escape(isset($this->vent['axn']) ? $this->vent['axn'] : NULL) . ",
            '" . $_SESSION['usuario']['skUsuario'] . "',
            '" . $this->sysController . "' )";
 
        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record);
        return $record; 
    }

    public function stpCUD_ventas() {

        $sql = "CALL stpCUD_ventas (
            " .escape(isset($this->vent['skVenta']) ? $this->vent['skVenta'] : NULL) . ",
            " .escape(isset($this->vent['skCotizacion']) ? $this->vent['skCotizacion'] : NULL) . ", 
            " .escape(isset($this->vent['axn']) ? $this->vent['axn'] : NULL) . ",
            '" . $_SESSION['usuario']['skUsuario'] . "',
            '" . $this->sysController . "' )";
 
        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record);
        return $record; 
    }

    public function stp_vent_actaEntrega() {

        $sql = "CALL stp_vent_actaEntrega (
            " .escape(isset($this->vent['skCotizacion']) ? $this->vent['skCotizacion'] : NULL) . ",
            " .escape(isset($this->vent['sRecibeEntrega']) ? $this->vent['sRecibeEntrega'] : NULL) . ", 
            " .escape(isset($this->vent['sTelefonoRecepcionEntrega']) ? $this->vent['sTelefonoRecepcionEntrega'] : NULL) . ", 
            " .escape(isset($this->vent['dFechaEntregaInstalacion']) ? $this->vent['dFechaEntregaInstalacion'] : NULL) . ", 
            " .escape(isset($this->vent['sObservacionesInstalacion']) ? $this->vent['sObservacionesInstalacion'] : NULL) . ", 
            " .escape(isset($this->vent['axn']) ? $this->vent['axn'] : NULL) . ",
            '" . $_SESSION['usuario']['skUsuario'] . "',
            '" . $this->sysController . "' )";
 
        $result = Conn::query($sql);
        if (!$result) {
            return false;
        }
        $record = Conn::fetch_assoc($result);
        utf8($record,FALSE);
        return $record; 
    }

    public function consultar_formasPago() {
        $sql = "SELECT CONCAT('(',cf.sCodigo,') ',cf.sNombre)  AS sNombre,cf.sCodigo FROM cat_formasPago cf  WHERE cf.skEstatus = 'AC'  ORDER BY cf.sNombre ASC   ";

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }
    public function consultar_metodosPago() {
        $sql = "SELECT  CONCAT('(',cm.sCodigo,') ',cm.sNombre) AS sNombre,cm.sCodigo FROM cat_metodosPago cm WHERE cm.skEstatus = 'AC'  ORDER BY cm.sNombre ASC   ";

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

    public function consultar_usosCFDI() {

        $sql = "SELECT CONCAT('(',cu.sClave,') ',cu.sNombre) AS sNombre,cu.sClave AS sCodigo FROM cat_usosCFDI cu where cu.skEstatus = 'AC' ORDER BY cu.sNombre ASC  ";

        $result = Conn::query($sql);
        if (!$result) {
            return FALSE;
        }
        return Conn::fetch_assoc_all($result);
    }

      

   


}
