var vent = {};

vent.coti_inde = {};
vent.coti_form = {};
vent.vent_coti = {};
vent.entr_coti = {};

vent.coti_inde.dataTableConf = {
    'serverSide': true,
    'ajax': {
        'url': window.location.href,
        'type': 'POST',
        'data': function (data) {
            data.axn = 'consulta';
            data.filters = core.dataFilterSend;
            data.generarExcel = core.generarExcel;
        }
    },
    'axn': 'consulta',
    'order': [[6, "desc"]],
    'columns': [
        {'title': 'E', 'data': 'estatus', 'dataType': 'string', 'tooltip': 'Estatus', 'filterT': 'Estatus'},
        {'title': 'Folio', 'data': 'iFolio', 'dataType': 'string','tooltip': 'Folio'},
        {'title': 'Nombre Comercial', 'data': 'sNombreCliente', 'dataType': 'string'},
        {'title': 'Razón Social', 'data': 'cliente', 'dataType': 'string'},
        {'title': 'Usuario Creacion', 'data': 'usuarioCreacion', 'dataType': 'string'},
        {'title': 'Total', 'data': 'fImporteTotal', 'dataType': 'string'},
        {'title': 'F. Creacion', 'data': 'dFechaCreacion', 'dataType': 'date'}
    ],

    "drawCallback": function () {
        core.dataTable.contextMenuCore(true);
        core.dataTable.changeColumnColor(1, 'success');
        core.dataTable.fastFilters(2, [], true);
        $('[data-toggle="tooltip"]').tooltip();
    },
    "columnDefs": [
        {
            "targets": [0],
            "width": '10px',
            "createdCell": function (td, cellData, rowData, row, col) {
                ((rowData.estatusIcono) ? $(td).html('<i class="' + rowData.estatusIcono + '"></i>') : $(td).html(cellData));
                $(td).addClass('text-center ' + ((rowData.estatusColor) ? rowData.estatusColor : 'text-primary'));
                ((rowData.estatusIcono) ? $(td).find('i').attr({"title": cellData, "data-toggle": "tooltip", "data-placement": "rigth"}) : '');

            }
        },
        {
            "targets": [1],
            "width": '10px'
        },
        {
            "targets": [2,3],
            "width": '40px'
        }
    ]
};

vent.coti_inde.visualizarCotizacionPDF = function visualizarCotizacionPDF(obj){
    window.open(core.SYS_URL+'sys/vent/coti-deta/detalle-cotizacion/'+obj.id+'/?axn=formatoPDF');
    return true;
};

vent.coti_inde.descargarCotizacionPDF = function descargarCotizacionPDF(obj){
    core.download(window.location.href,'GET', {
        axn: 'cotizacionPDF',
        id: obj.id
    });
    return true;
};

vent.coti_inde.visualizarVentaPDF = function visualizarCotizacionPDF(obj){
    window.open(core.SYS_URL+'sys/vent/coti-deta/detalle-cotizacion/'+obj.id+'/?axn=formatoVentaPDF');
    return true;
};

vent.coti_inde.descargarVentaPDF = function descargarCotizacionPDF(obj){
    core.download(window.location.href,'GET', {
        axn: 'ventaPDF',
        id: obj.id
    });
    return true;
};

vent.coti_inde.visualizarEntregaPDF = function visualizarEntregaPDF(obj){
    window.open(core.SYS_URL+'sys/vent/coti-deta/detalle-cotizacion/'+obj.id+'/?axn=formatoEntregaPDF');
    return true;
};

vent.coti_inde.descargarEntregaPDF = function descargarEntregaPDF(obj){
    core.download(window.location.href,'GET', {
        axn: 'entregaPDF',
        id: obj.id
    });
    return true;
};



vent.coti_form.validaciones = {
    skEmpresaSocioCliente: {
        validators: {
            notEmpty: {
                message: 'DATO REQUERIDO'
            }
        }
    },
    skCategoriaPrecio: {
        validators: {
            notEmpty: {
                message: 'DATO REQUERIDO'
            }
        }
    },
    skDivisa: {
        validators: {
            notEmpty: {
                message: 'DATO REQUERIDO'
            }
        }
    } 

}; 

vent.coti_inde.clonar = function clonar(obj) {
  
    $.ajax({
        url: '/sys',
        type: 'POST',
        data: {
            axn: 'clonar',
            skCotizacion: $(obj).val()
        },
        cache: false,
        processData: true,
        success: function (data) {
             
        }
    });
};

vent.coti_inde.cancelarVenta = function cancelarVenta(obj) {
    swal({
        title: "¿Desea cancelar la venta?",
        text: "Cotizacion  # "+core.rowDataTable.iFolio+" " ,
        type: "warning",
        confirmButtonClass: "btn-warning",
        confirmButtonText: "SI",
        showCancelButton: true,
        closeOnConfirm: false,
        showLoaderOnConfirm: true,
        animation: "slide-from-top"
    },
    function () {
        $.ajax({
            url: window.location.href,
            type: 'POST',
            data: {
                axn: 'cancelarVenta',
                skCotizacion: core.rowDataTable.skCotizacion
            },
            cache: false,
            processData: true,
            beforeSend: function () {
                toastr.info('Cancelar la Venta # '+core.rowDataTable.iFolio, 'Notificación');
            },
            success: function (response) {
                toastr.clear();

                if(!response.success){
                    toastr.error(response.message+ " Folio:" +core.rowDataTable.iFolio, 'Notificación');
                    swal.close();
                    core.dataTable.sendFilters(true);
                    return false;
                }

                toastr.success('Venta cancelada con exito # '+core.rowDataTable.iFolio, 'Notificación');
                swal("¡Notificación!", 'Venta cancelada con exito# '+core.rowDataTable.iFolio, "success");
                core.dataTable.sendFilters(true);
                 return true;
            }
        });
    });
   
};


vent.entr_coti.validaciones = {
    sRecibeEntrega: {
        validators: {
            notEmpty: {
                message: 'CAMPO REQUERIDO'
            }
        }
    },
    dFechaEntregaInstalacion: {
        validators: {
            notEmpty: {
                message: 'CAMPO REQUERIDO'
            }
        }
    },
    sTelefonoRecepcionEntrega: {
        validators: {
            notEmpty: {
                message: 'CAMPO REQUERIDO'
            }
        }
    },
    sObservacionesInstalacion: {
        validators: {
            notEmpty: {
                message: 'CAMPO REQUERIDO'
            }
        }
    } 
}; 